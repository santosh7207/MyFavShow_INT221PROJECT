
      function check()
      {
            var c,x,y;
    
       c=document.getElementById("t1").value; 
       if(c=="")
      {
        alert("Please fill the E-Mail ID");
         return false;
      }
      x=c.indexOf("@");
      y=c.indexOf(".");
      if(x<1)
      {alert("@ is missing in your email id");
       return false;}
      if(y<0)
      {alert(" .  is missing in your email id");
       return false;}
      if(y-x!=6)
      {alert("Invalid Email ID");
       return false;}
      if(c.length>y+2)
      {;}
      else
      {alert("Invalid EMail ID");
       return false;}
        var a;
        a=document.getElementById("t2").value;
        if(a=="")
      {
        alert("Please fill the password");
        return false;
      }
      else
        if(a.length<8)
      {
       alert("Password must contain six characters only");
       return false;
      }
      }
