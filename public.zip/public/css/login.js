function check()
    {
        var a;
      a=document.getElementById("t1").value;
      if(a=="")
      {
        alert("Please enter the First name");
        return false;
      }
    
      var b;
      b=document.getElementById("t2").value;
      if(b=="")
      {
        alert("Please enter the Last name");
        return false;
      }
      if(b<4)
      {
        alert("Enter valid Last name");
        return false;
      }
      var c,x,y;
      c=document.getElementById("t3").value; 
      if(c=="")
      {
          alert("Please fill the E-Mail ID");
          return false;
      }
      x=c.indexOf("@");
      y=c.indexOf(".");
      if(x<1)
      {
        alert("@ is missing in your email id");
        return false;
      }
      if(y<1)
      {
        alert(" .  is missing in your email id");
        return false;
      }
      if(y-x!=6)
      {
        alert("Invalid E-Mail ID");
        return false;
      }
      if(c.length>y+2)
      {;}
      else
      {
        alert("Invalid E-Mail ID");
        return false;
      }
      var d;
      d=document.getElementById("t4").value;
      if(d=="")
      {
        alert("Please fill the password");
        return false;
      }
      else
        if(d.length<8)
      {
       alert("Password must contain Eight characters");
       return false;
      }

    }